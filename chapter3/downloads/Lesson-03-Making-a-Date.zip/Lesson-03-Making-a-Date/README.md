# Lesson 3: Making a Date

Open START-HERE.html in Edge, Chrome, or Firefox. It is an offline study workbook; no server, account, or internet connection is required. Keep the audio and output folders beside the HTML file.

Exactly 200 numbered questions cover all eight Lesson 3 grammar topics, four reading labs, five listening labs, and a final checkpoint. All Japanese text uses kana. English explanations and answers are provided.

## Files

- START-HERE.html: guide, vocabulary, all questions, audio players, hidden answers and transcripts, progress tracking.
- output/pdf/Lesson-03-Workbook.pdf: printable guide, vocabulary, and 200 questions with writing space. Listening transcripts are excluded.
- output/pdf/Lesson-03-Answers-and-Transcripts.pdf: explanations for all 200 answers, reading translations, and listening transcripts/translations.
- audio/: normal and slow WAV files for five listening labs, plus a verb-form warmup at both speeds.

## Study plan

1. Session 1: guide and questions 001-040.
2. Session 2: questions 041-080.
3. Session 3: questions 081-120.
4. Session 4: questions 121-165.
5. Session 5: questions 166-200. Keep listening transcripts hidden until you answer.

Try each item before opening its answer. Compare your response and choose Correct or Review. Open responses have model answers, and natural alternatives may be correct. Each numbered question is worth one point; multipart questions require every requested part. Saved status is self-assessed, not automatic grading. Browser storage can be cleared or vary for local files, so use Export progress to keep a backup; Import progress restores that backup.

Aim for 8/10 on the final checkpoint, 24/30 on conjugation, and 20/25 on listening without the guide. Redo all mistakes the next day. These are study targets, not a guarantee of mastery.

## Audio

WAV files were generated locally using installed Japanese speech synthesis. The narration uses Microsoft Haruka Desktop; dialogue turns use Haruka and Ichiro when available. The slow versions are separately synthesized. All audio is synthetic and is original practice content, not publisher audio. Audio playback works offline.

## Scope and sources

This is an independent original supplement aligned to the publisher’s Lesson 3 topic outline. It does not reproduce textbook exercises, passages, or audio. Small amounts of extra vocabulary are glossed. The optional external resources may display kanji; the supplied study material does not.

- Official syllabus: https://bookclub2.japantimes.co.jp/download/files/genki3/genki-3rd_syllabus_E.pdf
- Optional publisher videos: https://genki.japantimes.co.jp/site/video/en/
